import { StandardSchemaV1 } from '@standard-schema/spec';

declare enum CollectionSortOrder {
	Manual = "MANUAL",
	BestSelling = "BEST_SELLING",
	AlphaAsc = "ALPHA_ASC",
	AlphaDesc = "ALPHA_DESC",
	PriceDesc = "PRICE_DESC",
	PriceAsc = "PRICE_ASC",
	CreatedDesc = "CREATED_DESC",
	Created = "CREATED",
	MostRelevant = "MOST_RELEVANT"
}
declare enum FulfillmentServiceType {
	GiftCard = "GIFT_CARD",
	Manual = "MANUAL",
	ThirdParty = "THIRD_PARTY"
}
declare enum ProductStatus {
	Active = "ACTIVE",
	Archived = "ARCHIVED",
	Draft = "DRAFT"
}
declare enum ProductVariantInventoryManagement {
	Shopify = "SHOPIFY",
	NotManaged = "NOT_MANAGED",
	FulfillmentService = "FULFILLMENT_SERVICE"
}
declare enum ProductVariantInventoryPolicy {
	Deny = "DENY",
	Continue = "CONTINUE"
}
declare enum WeightUnit {
	Kilograms = "KILOGRAMS",
	Grams = "GRAMS",
	Pounds = "POUNDS",
	Ounces = "OUNCES"
}
declare global {
	namespace Shopify {
		interface Data {
			intent?: IntentRequest;
		}
	}
}
declare global {
	var shopify: ShopifyGlobal;
	var polaris: InternalPolarisApi["global"] | undefined;
	interface HTMLButtonElement extends AugmentedElement<"button"> {
	}
	interface HTMLAnchorElement extends AugmentedElement<"a"> {
	}
	interface UIModalElement extends UIModalElement$1 {
	}
	interface SAppWindowElement extends SAppWindowElement$1 {
	}
	interface UINavMenuElement extends UINavMenuElement$1 {
	}
	interface SAppNavElement extends SAppNavElement$1 {
	}
	interface UITitleBarElement extends UITitleBarElement$1 {
	}
	interface UISaveBarElement extends UISaveBarElement$1 {
	}
	namespace React {
		interface ButtonHTMLAttributes<T> extends AugmentedElement<"button"> {
		}
		interface AnchorHTMLAttributes<T> extends AugmentedElement<"a"> {
		}
	}
	namespace JSX {
		interface IntrinsicElements extends AppBridgeElements {
		}
		interface IntrinsicAttributes extends AppBridgeAttributes {
		}
	}
	namespace Shopify {
		/**
		 * Data exposed by Shopify
		 */
		interface Data {
		}
	}
}
export interface Collection extends Resource {
	availablePublicationCount: number;
	description: string;
	descriptionHtml: string;
	handle: string;
	id: string;
	image?: Image$1 | null;
	productsAutomaticallySortedCount: number;
	productsCount: number;
	productsManuallySortedCount: number;
	publicationCount: number;
	ruleSet?: RuleSet | null;
	seo: {
		description?: string | null;
		title?: string | null;
	};
	sortOrder: CollectionSortOrder;
	storefrontId: string;
	templateSuffix?: string | null;
	title: string;
	updatedAt: string;
}
export interface Product extends Resource {
	availablePublicationCount: number;
	createdAt: string;
	descriptionHtml: string;
	handle: string;
	hasOnlyDefaultVariant: boolean;
	images: Image$1[];
	options: {
		id: string;
		name: string;
		position: number;
		values: string[];
	}[];
	productType: string;
	publishedAt?: string | null;
	tags: string[];
	templateSuffix?: string | null;
	title: string;
	totalInventory: number;
	totalVariants: number;
	tracksInventory: boolean;
	variants: Partial<ProductVariant>[];
	vendor: string;
	updatedAt: string;
	status: ProductStatus;
}
export interface ProductVariant extends Resource {
	availableForSale: boolean;
	barcode?: string | null;
	compareAtPrice?: Money | null;
	createdAt: string;
	displayName: string;
	fulfillmentService?: {
		id: string;
		inventoryManagement: boolean;
		productBased: boolean;
		serviceName: string;
		type: FulfillmentServiceType;
	};
	image?: Image$1 | null;
	inventoryItem: {
		id: string;
	};
	inventoryManagement: ProductVariantInventoryManagement;
	inventoryPolicy: ProductVariantInventoryPolicy;
	inventoryQuantity?: number | null;
	position: number;
	price: Money;
	product: Partial<Product>;
	requiresShipping: boolean;
	selectedOptions: {
		value?: string | null;
	}[];
	sku?: string | null;
	taxable: boolean;
	title: string;
	weight?: number | null;
	weightUnit: WeightUnit;
	updatedAt: string;
}
/**
 * Properties for the app nav element. This element configures the app nav in the Shopify admin.
 * @publicDocs
 */
export interface SAppNavAttributes {
	/**
	 * The navigation items to display, provided as link child elements. Each link creates a navigation item in the app's navigation menu. Include one link with `rel="home"` to set the default landing page. Commonly used to organize your app into logical sections (like "Products", "Orders", or "Settings").
	 */
	children?: any;
}
/**
 * Properties for links used as children.
 * @publicDocs
 */
export interface SAppNavLinkAttributes {
	/**
	 * The URL path for the navigation item. Must be a relative path within your app, such as `/products` or `/settings`. When clicked, it navigates the app to this route without a full page reload. The path should match a route defined in your app's routing configuration.
	 */
	href: string;
	/**
	 * Set to `"home"` to designate this link as the app's default landing page. When set, the link is hidden from the navigation menu. Only one link should have `rel="home"`.
	 */
	rel?: "home";
	/**
	 * The visible label text for the navigation item. Keep labels short (1-2 words) and use nouns that describe the destination (such as "Products", "Settings", or "Reports"). Avoid verbs like "Manage" or "View" to maintain consistency with Shopify admin navigation patterns.
	 */
	children?: string;
}
/**
 * Attributes for the app window element. This element displays a fullscreen modal window in the Shopify admin.
 * @publicDocs
 */
export interface SAppWindowAttributes {
	/**
	 * A unique identifier you assign to the app window element. Used when connecting buttons via `commandFor` or accessing the element with `document.getElementById()`. Choose a descriptive name like `"settings-window"` or `"edit-modal"`.
	 */
	id?: string;
	/**
	 * The URL of the content to display within the app window. Must point to a route within your app that renders the window content. The URL is loaded in an iframe when the window opens. Commonly used for multi-step workflows, bulk editors, or detailed views that need full-screen space.
	 */
	src: string;
}
export interface ShopifyGlobal {
	config: AppBridgeConfig;
	origin: string;
	ready: Promise<void>;
	/**
	 * Registers a signals implementation (e.g. from `@preact/signals`) so that
	 * reactive values returned by App Bridge use the app's own Signal class
	 * instead of the built-in lightweight shim. Any signals created before this
	 * call are migrated to the provided implementation.
	 *
	 * @param RealSignal - A Signal constructor compatible with `@preact/signals-core`
	 */
	setSignals(RealSignal: any): void;
	environment: EnvironmentApi;
	loading: LoadingApi;
	idToken: IdTokenApi;
	user: UserApi;
	toast: ToastApi;
	resourcePicker: ResourcePickerApi;
	scanner: ScannerApi;
	modal: ModalApi;
	saveBar: SaveBarApi;
	pos: PosApi;
	intents: IntentsApi;
	webVitals: WebVitalsApi;
	support: SupportApi;
	reviews: ReviewsApi;
	scopes: Scopes;
	picker: PickerApi;
	app: AppApi;
	shopifyQL: ShopifyQLApi;
	/**
	 * Entry point for Shopify tools.
	 *
	 * Enables apps to bind runtime handler functions for tools already
	 * declared in app extension configuration, which can be invoked by
	 * the platform on behalf of the app. Registered tools are scoped to
	 * the current app and persist for the lifetime of the app or until
	 * explicitly removed.
	 */
	tools: Tools;
}
export interface ToastOptions {
	/**
	 * The length of time in milliseconds the toast message should persist.
	 * @defaultValue 5000
	 */
	duration?: number;
	/**
	 * Display an error-styled toast.
	 * @defaultValue false
	 */
	isError?: boolean;
	/**
	 * Content of an action button.
	 */
	action?: string;
	/**
	 * Callback fired when the action button is clicked.
	 */
	onAction?: () => void;
	/**
	 * Callback fired when the dismiss icon is clicked.
	 */
	onDismiss?: () => void;
}
export interface UIModalAttributes extends _UIModalAttributes {
	children?: any;
}
export interface UINavMenuAttributes {
	children?: any;
}
export interface UISaveBarAttributes extends _UISaveBarAttributes {
	children?: any;
}
export interface UITitleBarAttributes extends _UITitleBarAttributes {
	children?: any;
}
interface Address {
	/**
	 * The customer's primary address.
	 */
	address1?: string;
	/**
	 * Any extra information associated with the address (Apartment #, Suite #, Unit #, etc.).
	 */
	address2?: string;
	/**
	 * The name of the customer's city.
	 */
	city?: string;
	/**
	 * The company name associated with address.
	 */
	company?: string;
	/**
	 * The first name of the customer.
	 */
	firstName?: string;
	/**
	 * 	The last name of the customer.
	 */
	lastName?: string;
	/**
	 * The phone number of the customer.
	 */
	phone?: string;
	/**
	 * The province or state of the address.
	 */
	province?: string;
	/**
	 * The country of the address.
	 */
	country?: string;
	/**
	 * The ZIP or postal code of the address.
	 */
	zip?: string;
	/**
	 * The name of the address.
	 */
	name?: string;
	/**
	 * The acronym of the province or state.
	 */
	provinceCode?: string;
	/**
	 * The Country Code in ISO 3166-1 (alpha-2) format.
	 */
	countryCode?: string;
}
interface AdminUser {
	/**
	 * The account access level of the logged-in user.
	 */
	accountAccess?: string;
}
interface AppApi {
	/**
	 * The list of extensions from the current app.
	 * @returns A promise that resolves to the array of ExtensionInfo containing extension status information.
	 *
	 * This array may be empty if the app has no extensions.
	 *
	 * @throws {Error} When the App API is not available or the request fails.
	 */
	extensions(): Promise<ExtensionInfo[]>;
}
interface AppBridgeAttributes {
}
interface AppBridgeConfig {
	/**
	 * The client ID (also known as the API key) for your application, found in the Shopify Partner Dashboard under your app's settings.
	 *
	 * You must provide this value using a `<meta name="shopify-api-key">` tag.
	 */
	apiKey: string;
	/**
	 * An allowlist of origins that your app can send authenticated fetch requests to.
	 *
	 * Set this property if your app needs to make authenticated requests to a domain other than your app's origin.
	 * Requests to your app's own domain (and its subdomains) are automatically allowed.
	 *
	 * Each value must be an origin in the format `scheme://hostname` or `scheme://hostname:port` (for example, `'https://example.com'` or `'https://example.com:8443'`).
	 */
	appOrigins?: string[];
	/**
	 * Configuration for enabling Web Vitals performance logging.
	 *
	 * Use this property during development for identifying performance issues.
	 */
	debug?: DebugOptions;
	/**
	 * An array of App Bridge feature names to disable in your app.
	 *
	 * Supported values:
	 * - `'fetch'` — Disables App Bridge's automatic fetch interceptor, which adds authentication headers to requests to the Shopify Admin API.
	 * - `'auto-redirect'` — Disables automatic redirection when the app is loaded outside of the Shopify Admin.
	 *
	 */
	disabledFeatures?: string[];
	/**
	 * The experimental features to enable in your app.
	 *
	 * This allows app developers to opt-in to experiement features.
	 *  @private
	 */
	experimentalFeatures?: string[];
	/**
	 * The base64-encoded host of the shop that's embedding your app.
	 * When decoded, the value has the format `admin.shopify.com/store/{shop-name}`.
	 *
	 * This property is automatically set by the host environment.
  
	 */
	host?: string;
	/**
	 * The locale of the admin user viewing your app, as an IETF BCP 47 language tag (for example, `'en-US'`, `'fr-FR'`, `'ja-JP'`).
	 *
	 * This reflects the language the merchant has chosen for the Shopify admin, not the shop's customer-facing locale.
	 *
	 * This property is automatically set by the host environment.
	 * @defaultValue 'en-US'
	 */
	locale?: string;
	/**
	 * The permanent `.myshopify.com` domain of the shop that's embedding your app (for example, `'my-store.myshopify.com'`).
	 * This is always the Shopify-assigned domain, not a custom domain.
	 *
	 * This property is automatically set by the host environment.
	 */
	shop?: string;
}
interface AppBridgeElements {
	"ui-modal": UIModalAttributes;
	"s-app-window": SAppWindowAttributes;
	"ui-nav-menu": UINavMenuAttributes;
	"s-app-nav": SAppNavAttributes;
	"ui-save-bar": UISaveBarAttributes;
	"ui-title-bar": UITitleBarAttributes;
	"s-page": SPageAttributes;
}
interface AugmentedElements {
	button: MenuItemProperties;
	a: MenuItemProperties;
}
interface Badge {
	/** The text content of the badge. Keep this short and descriptive (for example, "Draft", "Active", "Incomplete"). */
	content: string;
	/** The visual tone indicating status or importance. Choose a tone that matches the badge's meaning. */
	tone?: Tone;
	/** The progress indicator for the badge. Use this to show completion status for items that have progress states. */
	progress?: Progress;
}
interface BaseElementAttributes {
	id?: string;
	name?: string;
	class?: string;
	href?: string;
	rel?: string;
	target?: string;
	onclick?: string;
	children?: string;
}
interface BaseResource extends Resource {
	variants?: Resource[];
}
interface Cart {
	/**
	 * 	The total cost of the current cart including discounts, but before taxes and shipping. Value is based on the shop's existing currency settings.
	 */
	subTotal: string;
	/**
	 * The sum of taxes for the current cart. Value is based on the shop's existing currency settings.
	 */
	taxTotal: string;
	/**
	 * The total cost of the current cart, after taxes and discounts have been applied. Value is based on the shop's existing currency settings.
	 */
	grandTotal: string;
	/**
	 * The current discount applied to the entire cart.
	 */
	cartDiscount?: Discount;
	/**
	 * All current discounts applied to the entire cart and line items.
	 */
	cartDiscounts?: Discount[];
	/**
	 * The customer associated to the current cart.
	 */
	customer?: Customer;
	/**
	 * A list of lineItem objects.
	 */
	lineItems: LineItem[];
	/**
	 * A list of objects containing cart properties.
	 */
	properties: Record<string, string>;
}
interface ClosedIntentResponse {
	code?: "closed";
}
interface CollectionRule {
	column: string;
	condition: string;
	relation: string;
}
interface CustomSale {
	/**
	 * Price of line item
	 */
	price: number;
	/**
	 * Quantity of line item.
	 */
	quantity: number;
	/**
	 * Title of line item.
	 */
	title: string;
	/**
	 * If line item charges tax.
	 */
	taxable: boolean;
}
interface Customer {
	/**
	 * The ID of existing customer.
	 */
	id: number;
	/**
	 * The email for a new customer.
	 */
	email?: string;
	/**
	 * The first name for new customer.
	 */
	firstName?: string;
	/**
	 * The last name for new customer.
	 */
	lastName?: string;
	/**
	 * The note for new customer.
	 */
	note?: string;
}
interface DebugOptions {
	/**
	 * Enables or disables the logging of web performance metrics (Web Vitals) in the browser's console.
	 *
	 * When set to `true`, the app will log Core Web Vitals (such as LCP, INP, and CLS) and other relevant performance metrics to help developers understand the real-world performance of their app. This can be useful for debugging performance issues during development or in a staging environment.
	 *
	 * This field is optional and defaults to `false`, meaning that web vitals logging is disabled by default to avoid performance overhead and unnecessary console output in production environments.
	 * @defaultValue false
	 */
	webVitals?: boolean;
}
interface Device {
	/**
	 * The name of the device.
	 */
	name: string;
	/**
	 * The unique ID associated device ID and app ID..
	 */
	serialNumber: string;
}
interface Discount {
	/**
	 * Amount of discount. Only for fixed or percentage discounts.
	 */
	amount: number;
	/**
	 * Description of discount.
	 */
	discountDescription?: string;
	/**
	 * Type of discount.
	 */
	type: DiscountType;
}
interface EnvironmentApi extends Required<_EnvironmentApi> {
}
interface ErrorIntentResponse {
	code?: "error";
	message?: string;
	issues?: StandardSchemaV1.Issue[];
}
interface ExtensionInfo<Type extends ExtensionType = ExtensionType> {
	/**
	 * The unique identifier for the extension.
	 */
	handle: string;
	/**
	 * List of activation records for the extension.
	 * The shape depends on the extension type:
	 * - UI extensions have activations with only `target`
	 * - Theme app extensions have nested activations representing blocks/embeds
	 */
	activations: Type extends "ui_extension" ? UiExtensionActivation[] : Type extends "theme_app_extension" ? ThemeExtensionActivation[] : never;
	/**
	 * The type of the extension.
	 */
	type: Type;
}
interface Filters {
	/**
	 * Whether to show hidden resources, referring to products that are not published on any sales channels.
	 * @defaultValue true
	 */
	hidden?: boolean;
	/**
	 * Whether to show product variants. Only applies to the Product resource type picker.
	 * @defaultValue true
	 */
	variants?: boolean;
	/**
	 * Whether to show [draft products](https://help.shopify.com/en/manual/products/details?shpxid=70af7d87-E0F2-4973-8B09-B972AAF0ADFD#product-availability).
	 * Only applies to the Product resource type picker.
	 * Setting this to undefined will show a badge on draft products.
	 * @defaultValue true
	 */
	draft?: boolean | undefined;
	/**
	 * Whether to show [archived products](https://help.shopify.com/en/manual/products/details?shpxid=70af7d87-E0F2-4973-8B09-B972AAF0ADFD#product-availability).
	 * Only applies to the Product resource type picker.
	 * Setting this to undefined will show a badge on draft products.
	 * @defaultValue true
	 */
	archived?: boolean | undefined;
	/**
	 * GraphQL initial search query for filtering resources available in the picker.
	 * See [search syntax](https://shopify.dev/docs/api/usage/search-syntax) for more information.
	 * This query is not visible to merchants and runs server-side. Use it to programmatically restrict results (for example, `vendor:Acme`) without exposing the filter logic.
	 */
	query?: string;
}
interface Header {
	/**
	 * The label text displayed at the top of the table column. Use clear, concise labels that describe the data in that column (for example, "Price", "Status", "Last Updated").
	 */
	content?: string;
	/**
	 * The data type that controls column formatting and text alignment. Use `'number'` for currency, prices, or numeric values (displays right-aligned), or `'string'` for text content (displays left-aligned).
	 * @defaultValue 'string'
	 */
	type?: "string" | "number";
}
interface Image$1 {
	id: string;
	altText?: string;
	originalSrc: string;
}
interface Intent {
	readonly action: string;
	readonly type: string;
	readonly data: {
		[key: string]: any;
	};
	finish: Finish;
}
interface IntentActivity {
	/**
	 * A Promise that resolves when the intent workflow completes, returning the response.
	 */
	complete?: Promise<IntentResponse>;
}
interface IntentQuery extends IntentQueryOptions {
	action: IntentAction;
	type: IntentType;
}
interface IntentQueryOptions {
	/**
	 * The resource identifier for edit actions (e.g., 'gid://shopify/Product/123').
	 */
	value?: string;
	/**
	 * Additional data required for certain intent types.
	 * For example:
	 * - Discount creation requires { type: 'amount-off-product' | 'amount-off-order' | 'buy-x-get-y' | 'free-shipping' }
	 * - ProductVariant creation requires { productId: 'gid://shopify/Product/123' }
	 * - Metaobject creation requires { type: 'shopify--color-pattern' }
	 */
	data?: {
		[key: string]: unknown;
	};
}
interface IntentRequest {
	action: string;
	type: string;
	value?: unknown;
	data?: {
		[key: string]: unknown;
	};
}
interface IntentRequestApi {
	readonly value: IntentRequest | null;
	subscribe(callback: (value: IntentRequest | null) => void): () => void;
}
interface IntentResponseApi {
	/**
	 * If in an intent workflow, resolves the intent with a success response and the provided data, if any.
	 * @param data - The data to include in the success response.
	 */
	ok: (data?: SuccessIntentResponse["data"]) => Promise<void>;
	/**
	 * If in an intent workflow, resolves the intent with an error response and the provided message and issues, if any.
	 * @param message - The message to include in the error response.
	 * @param issues - The issues to include in the error response.
	 */
	error: (message: string, issues?: StandardSchemaV1.Issue[]) => Promise<void>;
	/**
	 * If in an intent workflow, resolves the intent with a closed response.
	 */
	closed: () => Promise<void>;
}
interface IntentsApi extends PublicIntentsApi {
	register(callback: (intent: Intent) => void): () => void;
}
interface InternalPolarisApi {
	global: unknown;
}
interface LineItem {
	/**
	 * Unique id of line item
	 */
	uuid: string;
	/**
	 * Price of line item
	 */
	price?: number;
	/**
	 * Quantity of line item.
	 */
	quantity: number;
	/**
	 * Title of line item.
	 */
	title?: string;
	/**
	 * Variant identifier for line item.
	 */
	variantId?: number;
	/**
	 * Product identifier for line item.
	 */
	productId?: number;
	/**
	 * Discount applied to line item.
	 */
	discounts: Discount[];
	/**
	 * If line item charges tax.
	 */
	taxable: boolean;
	/**
	 * Stock keeping unit of the line item.
	 */
	sku?: string;
	/**
	 * Vendor of line item.
	 */
	vendor?: string;
	/**
	 * Properties of the line item.
	 */
	properties: {
		[key: string]: string;
	};
	/**
	 * If the line item is a gift card.
	 */
	isGiftCard: boolean;
}
interface Location$1 {
	/**
	 * The ID of current location.
	 */
	id: number;
	/**
	 * The status of current location.
	 */
	active: boolean;
	/**
	 * The name of current location.
	 */
	name: string;
	/**
	 * The type of current location.
	 */
	locationType?: string;
	/**
	 * The primary address of current location.
	 */
	address1?: string;
	/**
	 * Any extra information associated with the address (Apartment #, Suite #, Unit #, etc.).
	 */
	address2?: string;
	/**
	 * The ZIP or postal code of the address.
	 */
	zip?: string;
	/**
	 * The name of the city.
	 */
	city?: string;
	/**
	 * TThe province or state of the address.
	 */
	province?: string;
	/**
	 * The Country Code in ISO 3166-1 (alpha-2) format.
	 */
	countryCode?: string;
	/**
	 * The country of the address.
	 */
	countryName?: string;
	/**
	 * 	The phone number of the location.
	 */
	phone?: string;
}
interface MenuItemProperties {
	variant?: "primary" | "breadcrumb" | null | undefined;
	tone?: "critical" | "default";
	disabled?: boolean;
	loading?: boolean | string;
}
interface ModalApi extends Required<_ModalApi> {
}
interface POSUser {
	/**
	 * The staff member's numeric ID.
	 */
	id?: number;
	/**
	 * The user's first name.
	 */
	firstName?: string;
	/**
	 * The user's last name.
	 */
	lastName?: string;
	/**
	 * The user's email address.
	 */
	email?: string;
	/**
	 * The account access level of the logged-in user.
	 */
	accountAccess?: string;
	/**
	 * The user's account type.
	 */
	accountType?: string;
}
interface PickerItem {
	/**
	 * The unique identifier for this item. This ID is returned in the selection array when the merchant selects this item. Use an ID that helps you identify the item in your system (for example, template IDs, review IDs, or custom option keys).
	 */
	id: string;
	/**
	 * The primary text displayed in the first column. This is typically the item's name or title and is the most prominent text in the row.
	 */
	heading: string;
	/**
	 * Additional data displayed in subsequent columns after the heading. Each value appears in its own column, and the order must match the `headers` array. For example, if headers are `["Price", "Status"]`, then data would be `[19.99, "Active"]`.
	 */
	data?: DataPoint[];
	/**
	 * Whether the item can be selected. When `true`, the item is disabled and can't be selected. Disabled items appear grayed out. Use this for items that are unavailable or don't meet selection criteria.
	 * @defaultValue false
	 */
	disabled?: boolean;
	/**
	 * Whether the item is preselected when the picker opens. When `true`, the item appears selected by default. Merchants can still deselect preselected items. Use this to show current selections or suggest default choices.
	 */
	selected?: boolean;
	/**
	 * Status or context badges displayed next to the heading in the first column. Use badges to highlight item state, completion status, or other important attributes (for example, "Draft", "Published", "Incomplete").
	 */
	badges?: Badge[];
	/**
	 * A small preview image or icon displayed at the start of the row. Thumbnails help merchants visually identify items at a glance. Provide a URL to the image file.
	 */
	thumbnail?: {
		url: string;
	};
}
interface PickerOptions {
	/**
	 * The heading displayed at the top of the picker modal. Use a clear, descriptive title that tells merchants what they're selecting.
	 */
	heading: string;
	/**
	 * The selection mode for the picker. Pass `true` to allow unlimited selections, `false` for single-item selection only, or a number to set a maximum selection limit (for example, `3` allows up to three items).
	 * @defaultValue false
	 */
	multiple?: boolean | number;
	/**
	 * The column headers for the picker table. Define headers to label and organize the data columns displayed for each item. The header order determines the column layout.
	 */
	headers?: Header[];
	/**
	 * The list of items that merchants can select from. Each item appears as a row in the picker table.
	 */
	items: PickerItem[];
}
interface PosApi {
	/**
	 * Provides methods to read and modify the current POS cart, including line items, discounts, customers, and properties.
	 */
	cart: PosCart;
	/**
	 * Closes the app and returns to the POS screen.
	 */
	close: PosClose;
	/**
	 * Returns information about the POS device, including its name and serial number.
	 */
	device: PosDevice;
	/**
	 * Returns information about the current POS location, including its ID, name, address, and status.
	 */
	location: PosLocation;
}
interface PrivilegedAdminUser extends AdminUser {
	/**
	 * The staff member's numeric ID.
	 */
	id?: number;
	/**
	 * The staff member's full name.
	 */
	name?: string;
	/**
	 * The staff member's email address.
	 */
	email?: string;
}
interface PublicIntentsApi {
	/**
	 * The current intent request as a subscribable.
	 *
	 * When the app isn't running inside an intent workflow, the current value is `null`.
	 */
	request: IntentRequestApi;
	/**
	 * Invoke an intent using the object syntax.
	 *
	 * @param query - Structured intent description, including `action` and `type`.
	 * @returns A promise for an {@link IntentActivity} that completes with an
	 *          {@link IntentResponse}.
	 */
	invoke?(query: IntentQuery): Promise<IntentActivity>;
	/**
	 * Invoke an intent using the URL syntax.
	 *
	 * URL format: `action:type[,value][?params]`.
	 *
	 * @param intentURL - Intent in URL form, e.g. `create:shopify/Product` or
	 *                    `edit:shopify/Product,gid://shopify/Product/123?title=Updated` or
	 *                    `edit:gid://shopify/Product/123`.
	 * @param options - Optional supplemental inputs such as `value` or `data`.
	 * @returns A promise for an {@link IntentActivity} that completes with an
	 *          {@link IntentResponse}.
	 */
	invoke?(intentURL: string, options?: IntentQueryOptions): Promise<IntentActivity>;
	/**
	 * If in an intent workflow, provides mechanisms to resolve the intent with a given response.
	 */
	response?: IntentResponseApi;
}
interface Resource {
	/** in GraphQL id format, ie 'gid://shopify/Product/1' */
	id: string;
}
interface ResourcePickerOptions<ResourceType extends keyof ResourceTypes = keyof ResourceTypes> {
	/**
	 * The type of Shopify resource to select: `'product'` for products, `'variant'` for specific product variants, or `'collection'` for collections. This determines what appears in the picker and what data structure is returned.
	 */
	type: ResourceType;
	/**
	 * The action verb that appears in the title as the primary action of the resource picker. "Add" prompts merchants that they are appending to an existing list, while "select" they'll choose a resource for a specific purpose or replacing selections.
	 * @defaultValue 'add'
	 */
	action?: "add" | "select";
	/**
	 * Filtering options that control which resources appear in the resourcepicker. Use filters to restrict resources by publication status, include or exclude variants, or apply custom search criteria. This helps merchants find relevant items faster.
	 */
	filter?: Filters;
	/**
	 * Whether to allow selecting multiple items of a specific type. If a number is provided, limit selections to that maximum. When `type` is `'product'`, merchants can still select multiple variants from a single product even when `multiple` is `false`.
	 * @defaultValue false
	 */
	multiple?: boolean | number;
	/**
	 * Initial GraphQL search query for filtering resources available in the resource picker. See [search syntax](https://shopify.dev/docs/api/usage/search-syntax) for more information.
	 * This is displayed in the search bar when the picker is opened and can be edited by users.
	 * For most use cases, you should use the `filter.query` option instead which doesn't show the query in the UI.
	 * @defaultValue ''
	 */
	query?: string;
	/**
	 * Resources that should be preselected when the picker is opened. Use this for edit workflows to show what products are already in a bundle, collection, or promotional set. Merchants can see current selections and modify them before confirming.
	 * @defaultValue []
	 */
	selectionIds?: BaseResource[];
}
interface ReviewRequestDeclinedResponse {
	/**
	 * Indicates the review modal was not displayed.
	 */
	success: false;
	/**
	 * A code identifying why the modal was not displayed, such as rate limits or merchant eligibility.
	 */
	code: ReviewRequestDeclinedCode;
	/**
	 * A human-readable message explaining why the modal was not displayed.
	 */
	message: string;
}
interface ReviewRequestSuccessResponse {
	/**
	 * Indicates the review modal was successfully displayed.
	 */
	success: true;
	/**
	 * The response code. Always `'success'` for a successful request.
	 */
	code: "success";
	/**
	 * A human-readable message confirming the modal was shown.
	 */
	message: "Review modal shown successfully";
}
interface ReviewsApi {
	/**
	 * Requests an app review modal. The modal only displays if [rate limits and eligibility conditions](#rate-limits-restrictions) are met. Returns a Promise that resolves to a response object with `success`, `code`, and `message` properties indicating whether the modal was shown and, if not, the reason why.
	 */
	request(): Promise<ReviewRequestResponse>;
}
interface RuleSet {
	appliedDisjunctively: boolean;
	rules: CollectionRule[];
}
interface SAppNavElement$1 extends HTMLElement {
}
interface SAppWindowElement$1 extends Omit<HTMLElement, "addEventListener" | "removeEventListener">, Required<Omit<_SAppWindowElement, "src" | "contentWindow">>, Pick<_SAppWindowElement, "src" | "contentWindow"> {
}
interface SPageAttributes extends SPageElement {
}
interface SPageChildren {
	/**
	 * The main call-to-action button, typically "Save" or "Create". Appears prominently
	 * on the right side of the title bar. Only one primary action should be used per page
	 * to maintain clear visual hierarchy. Use `slot="primary-action"` on an `s-button` element.
	 */
	primaryAction?: HTMLElement;
	/**
	 * Additional action buttons that appear next to the primary action. Use for secondary
	 * operations like "Cancel", "Delete", or grouped actions using `s-menu`. Multiple buttons
	 * can be added. Use `slot="secondary-actions"` on `s-button` elements. For dropdown menus,
	 * combine with [`commandFor`](/docs/api/app-home/polaris-web-components/actions/button#properties-propertydetail-commandFor) attribute and an `s-menu` element.
	 */
	secondaryActions?: HTMLElement[];
	/**
	 * A navigation link that appears before the page heading, typically used for "Back"
	 * navigation. Helps merchants understand their location and return to parent pages.
	 * Use `slot="breadcrumb-actions"` on a Link element with an `href` attribute.
	 */
	breadcrumbActions?: HTMLElement;
	/**
	 * A status badge displayed next to the page heading. Use to indicate page state such as
	 * "Draft", "Published", or "Archived". Use `slot="accessory"` on an `s-badge` element
	 * with a `tone` attribute (`info`, `success`, `warning`, or `critical`) to convey status.
	 */
	accessory?: HTMLElement;
}
interface SPageElement {
	/**
	 * The page title displayed in the title bar. Use a clear, descriptive heading that
	 * helps merchants understand the current context, such as "Edit Product" or "Order #1234".
	 */
	heading?: string;
	/**
	 * Child elements that populate the title bar slots. Use slots to add action buttons,
	 * breadcrumb navigation, and status badges to the title bar.
	 */
	children?: SPageChildren;
}
interface SaveBarApi extends Required<_SaveBarApi> {
}
interface ScannerApi {
	/**
	 * Opens the device camera to scan a barcode. Returns a Promise that resolves to a `ScannerPayload` containing the scanned data.
	 */
	capture(): Promise<ScannerPayload>;
}
interface ScannerPayload {
	/**
	 * The scanned barcode data as a string.
	 */
	data: string;
}
interface Scopes {
	/**
	 * Returns the current access scopes for this app on this shop, including which are granted, required, and optional.
	 */
	query: () => Promise<ScopesDetail>;
	/**
	 * Opens a permission grant modal asking the merchant to grant the specified scopes.
	 *
	 * The scopes must be [access scope](https://shopify.dev/docs/api/usage/access-scopes) handles (for example, `'read_products'` or `'write_orders'`) that are declared as optional in your app configuration.
	 *
	 * See the [permission grant modal](/docs/apps/build/authentication-authorization/app-installation/manage-access-scopes#request-access-scopes-using-the-app-bridge-api-for-embedded-apps) documentation for more details.
	 */
	request: (scopes: Scope[]) => Promise<ScopesRequestResponse>;
	/**
	 * Revokes the specified optional scopes from this app on this shop.
	 *
	 * The scopes must be [access scope](https://shopify.dev/docs/api/usage/access-scopes) handles (for example, `'read_products'` or `'write_orders'`) that are currently granted and declared as optional. Required scopes cannot be revoked.
	 */
	revoke: (scopes: Scope[]) => Promise<ScopesRevokeResponse>;
}
interface ScopesDetail {
	/**
	 * The scopes currently granted to this app on this shop. This includes both required and optional scopes.
	 */
	granted: Scope[];
	/**
	 * The scopes declared as required in your app configuration. These are always granted at install time and cannot be revoked by the app.
	 */
	required: Scope[];
	/**
	 * The scopes declared as optional in your app configuration. These may or may not be currently granted — check `granted` to see which are active.
	 */
	optional: Scope[];
}
interface ScopesRequestResponse {
	/**
	 * The merchant's response: `'granted-all'` if they accepted all requested scopes, or `'declined-all'` if they declined.
	 */
	result: UserResult;
	/**
	 * The updated scopes for this app on this shop after the merchant's response.
	 */
	detail: ScopesDetail;
}
interface ScopesRevokeResponse {
	/**
	 * The updated scopes for this app on this shop after the revocation.
	 */
	detail: ScopesDetail;
}
interface ShopifyQLApi {
	available(): Promise<boolean>;
}
interface SuccessIntentResponse {
	code?: "ok";
	data?: {
		[key: string]: unknown;
	};
}
interface SupportApi {
	/**
	 * Registers a callback function to run when the merchant clicks the support button. Pass `null` to unregister a previously registered handler.
	 * @param callback - The function to call when support is requested, or `null` to unregister.
	 */
	registerHandler?: (callback: SupportCallback | null) => Promise<void>;
}
interface ThemeAppBlockActivation {
	/**
	 * The target identifier for the block/embed placement within the theme.
	 * For example, `template--product.alternate/main/my_app_product_rating_GPzUYy`.
	 */
	target: string;
	/**
	 * The theme ID where this block/embed is activated.
	 * Format: `gid://shopify/OnlineStoreTheme/{id}`
	 */
	themeId: string;
}
interface ThemeExtensionActivation {
	/**
	 * The target location type for this block/embed.
	 * - `section` for blocks
	 * - `head`, `body`, or `compliance_head` for embeds
	 */
	target: ThemeAppBlockTarget | ThemeAppEmbedTarget;
	/**
	 * The filename of the block/embed within the theme app extension (without extension).
	 * This is configured by the developer when creating the block file.
	 */
	handle: string;
	/**
	 * The developer-configured display name of this block/embed, defined in the block's schema.
	 * @see https://shopify.dev/docs/apps/build/online-store/theme-app-extensions/configuration#schema
	 */
	name: string;
	/**
	 * The availability status of this block/embed.
	 */
	status: ActivationStatus;
	/**
	 * List of theme-specific activations for this block/embed.
	 * Contains where the block is actually placed within themes.
	 */
	activations: ThemeAppBlockActivation[];
}
interface ToastApi {
	/**
	 * Displays a Toast notification in the Shopify admin.
	 *
	 * @param message - The message to be displayed in the Toast notification.
	 * @param opts - Options for the Toast notification.
	 *
	 * @returns The ID of the Toast notification.
	 */
	show: ToastShow;
	/**
	 * Hides a Toast notification in the Shopify admin.
	 *
	 * @param id - The ID of the Toast notification to be hidden.
	 */
	hide: ToastHide;
}
interface Tools {
	register: RegisterFunction;
	unregister: UnregisterFunction;
	clear: ClearFunction;
}
interface UIModalElement$1 extends Omit<HTMLElement, "addEventListener" | "removeEventListener">, Required<Omit<_UIModalElement, "content" | "src" | "contentWindow">>, Pick<_UIModalElement, "content" | "src" | "contentWindow"> {
}
interface UINavMenuElement$1 extends HTMLElement {
}
interface UISaveBarChildren {
	button?: {
		id?: string;
		class?: string;
		children?: string;
		disabled?: boolean;
		loading?: boolean;
		name?: string;
		onclick?: string;
		variant?: "primary";
	};
}
interface UISaveBarElement$1 extends Omit<HTMLElement, "addEventListener" | "removeEventListener">, Required<_UISaveBarElement> {
}
interface UITitleBarChildren {
	/**
	 * Note that anchor tag elements are not supported in Remix. You can use Remix's `<Link>` component instead.
	 */
	a?: BaseElementAttributes & {
		variant?: "breadcrumb" | "primary";
	};
	button?: BaseElementAttributes & {
		variant?: "breadcrumb" | "primary";
		tone?: "critical" | "default";
	};
	section?: {
		label?: string;
		children?: {
			a?: BaseElementAttributes;
			button?: BaseElementAttributes;
		};
	};
}
interface UITitleBarElement$1 extends Omit<HTMLElement, "title"> {
}
interface UiExtensionActivation {
	/**
	 * The target identifier for the extension activation.
	 * For example, `purchase.thank-you.block.render`.
	 */
	target: string;
}
interface User extends PrivilegedAdminUser, AdminUser, POSUser {
}
interface WebVitalsApi {
	/**
	 * Registers a callback to receive Web Vitals performance data. Pass `null` to unregister a previously registered callback.
	 */
	onReport?: (callback: WebVitalsCallback | null) => Promise<void>;
}
interface WebVitalsMetric {
	/**
	 * A unique identifier for this metric measurement instance.
	 */
	id: string;
	/**
	 * The name of the metric, such as `LCP`, `FCP`, `CLS`, `INP`, `TTFB`, or `FID`.
	 */
	name: string;
	/**
	 * The measured value of the metric. Units depend on the metric name (milliseconds for timing metrics, unitless for CLS).
	 */
	value: number;
	/**
	 * The country code where the metric was collected, if available.
	 */
	country?: string;
	/**
	 * The App Bridge build version that produced the metric, in the form
	 * `<package-version>` or `<package-version>+<short-commit-sha>`. Used to
	 * attribute reports to a specific deploy.
	 */
	version?: string;
}
interface WebVitalsReport {
	/**
	 * The array of Web Vitals metric measurements included in this report.
	 */
	metrics: WebVitalsMetric[];
}
interface _EnvironmentApi {
	/**
	 * Whether the app is running inside the Shopify Mobile app.
	 */
	mobile?: boolean;
	/**
	 * Whether the app is embedded in the Shopify admin.
	 */
	embedded?: boolean;
	/**
	 * Whether the app is running inside the Shopify POS app.
	 */
	pos?: boolean;
	/**
	 * Whether the app is running as an intent.
	 */
	intent?: boolean;
}
interface _ModalApi {
	/**
	 * Shows the modal element. An alternative to the `showOverlay` instance method on the `s-modal` component.
	 * @param id A unique identifier for the Modal
	 */
	show?(id: string): Promise<void>;
	/**
	 * Hides the modal element. An alternative to the `hideOverlay` instance method on the `s-modal` component.
	 * @param id A unique identifier for the Modal
	 */
	hide?(id: string): Promise<void>;
	/**
	 * Toggles the modal element visibility. An alternative to the `toggleOverlay` instance method on the `s-modal` component.
	 * @param id A unique identifier for the Modal
	 */
	toggle?(id: string): Promise<void>;
}
interface _PosCart {
	/**
	 * Fetch the current cart.
	 */
	fetch?(): Promise<Cart>;
	/**
	 * Subscribe the cart changes.
	 */
	subscribe?(onSubscribe: CartSubscriber): Unsubscribe;
	/**
	 * Add a new or existing customer to the cart.
	 */
	setCustomer?(customer: Customer): Promise<void>;
	/**
	 * Remove the current customer from the cart.
	 */
	removeCustomer?(): Promise<void>;
	/**
	 * Add a new address to a customer.
	 */
	addAddress?(address: Address): Promise<void>;
	/**
	 * Update an address for a customer.
	 */
	updateAddress?(index: number, address: Address): Promise<void>;
	/**
	 * Apply a percentage or fixed amount discount to the whole cart.
	 */
	applyCartDiscount?(type: DiscountType, discountDescription: string, amount: string): Promise<void>;
	/**
	 * Apply a code discount to the whole cart.
	 */
	applyCartCodeDiscount?(code: string): Promise<void>;
	/**
	 * Remove the discount applied to the whole cart.
	 */
	removeCartDiscount?(): Promise<void>;
	/**
	 * Clears all applied discounts from the cart and optionally disables automatic discounts.
	 */
	removeAllDiscounts?(disableAutomaticDiscounts: boolean): Promise<void>;
	/**
	 * Add properties for the cart.
	 */
	addCartProperties?(properties: Record<string, string>): Promise<void>;
	/**
	 * Remove properties from the cart.
	 */
	removeCartProperties?(keys: string[]): Promise<void>;
	/**
	 * Add custom sale for the cart.
	 */
	addCustomSale?(customSale: CustomSale): Promise<void>;
	/**
	 * Clear all contents from the cart.
	 */
	clear?(): Promise<void>;
	/**
	 * Add a product to the cart.
	 */
	addLineItem?(variantId: number, quantity: number): Promise<void>;
	/**
	 * Make changes to a line item in the cart.
	 */
	updateLineItem?(uuid: string, quantity: number): Promise<void>;
	/**
	 * Remove a line item in the cart.
	 */
	removeLineItem?(uuid: string): Promise<void>;
	/**
	 * Apply a discount to a line item.
	 */
	setLineItemDiscount?(uuid: string, type: DiscountType, discountDescription: string, amount: string): Promise<void>;
	/**
	 * Remove a discount from a line item.
	 */
	removeLineItemDiscount?(uuid: string): Promise<void>;
	/**
	 * Add properties to a line item.
	 */
	addLineItemProperties?(uuid: string, properties: Record<string, string>): Promise<void>;
	/**
	 * Remove properties from a line item.
	 */
	removeLineItemProperties?(uuid: string, properties: string[]): Promise<void>;
}
interface _SAppWindowElement {
	/**
	 * Gets or sets the URL of the content displayed in the app window. Changing this value while the window is open navigates to the new URL. Commonly used for dynamic navigation within an open window.
	 */
	src?: string;
	/**
	 * Returns the Window object of the app window iframe, or `null` if the window is closed. Use this to communicate with the iframe content via `postMessage()` or access its document. Only accessible when the app window is open.
	 */
	readonly contentWindow?: Window | null;
	/**
	 * Opens the app window and displays the content from the `src` URL. Returns a Promise that resolves when the window is fully visible. Use `await` or `.then()` to run code after the window opens. Commonly used for launching workflows triggered by user actions.
	 */
	show?(): Promise<void>;
	/**
	 * Closes the app window. Returns a Promise that resolves when the window is fully hidden. Any unsaved changes in forms with `data-save-bar` will prompt the user before closing. Commonly used for programmatic close after completing a workflow.
	 */
	hide?(): Promise<void>;
	/**
	 * Toggles the app window between open and closed states. Returns a Promise that resolves when the transition completes. Opens the window if closed, closes it if open. Commonly used for toggle buttons that control window visibility.
	 */
	toggle?(): Promise<void>;
	/**
	 * Adds an event listener for app window lifecycle events. Supported events: `show` fires when the window opens, `hide` fires when the window closes. Commonly used for tracking analytics, updating UI state, or cleaning up resources when the window closes.
	 */
	addEventListener?(type: "show" | "hide", listener: EventListenerOrEventListenerObject): void;
	/**
	 * Removes a previously added event listener. Pass the same event type and listener function that was used with `addEventListener()`. Commonly used for cleanup when a component unmounts to prevent memory leaks.
	 */
	removeEventListener?(type: "show" | "hide", listener: EventListenerOrEventListenerObject): void;
}
interface _SaveBarApi {
	/**
	 * Displays the save bar to indicate unsaved changes. Call this when you want to prompt the merchant to save.
	 * @param id A unique identifier for the save bar
	 */
	show?(id: string): Promise<void>;
	/**
	 * Hides the save bar. Call this after the merchant saves or discards their changes.
	 * @param id A unique identifier for the save bar
	 */
	hide?(id: string): Promise<void>;
	/**
	 * Toggles save bar visibility between shown and hidden states.
	 * @param id A unique identifier for the save bar
	 */
	toggle?(id: string): Promise<void>;
	/**
	 * Prompts the merchant to confirm before leaving the page when there are unsaved changes. The promise resolves when the merchant confirms or when no save bar is visible. Use this before programmatic navigation (for example, using `window.location` or custom routing) to prevent accidental data loss.
	 */
	leaveConfirmation?(): Promise<void>;
}
interface _UIModalAttributes {
	/**
	 * A unique identifier for the Modal
	 */
	id?: string;
	/**
	 * The size of the modal.
	 *
	 * Before the Modal is shown, this can be changed to any of the provided values.
	 * After the Modal is shown, this can can only be changed between `small`, `base`, and `large`.
	 *
	 * @defaultValue "base"
	 */
	variant?: "small" | "base" | "large" | "max";
	/**
	 * The URL of the content to display within a Modal.
	 * If provided, the Modal will display the content from the provided URL
	 * and any children other than the [ui-title-bar](/docs/api/app-bridge-library/web-components/ui-title-bar)
	 * and [ui-save-bar](/docs/api/app-bridge-library/web-components/ui-save-bar) elements will be ignored.
	 */
	src?: string;
	/**
	 * The content to display within a Modal.
	 * You can provide a single HTML element with children
	 * and the [ui-title-bar](/docs/api/app-bridge-library/web-components/ui-title-bar)
	 * element to configure the Modal title bar.
	 */
	children?: HTMLCollection & UITitleBarAttributes;
}
interface _UIModalElement {
	/**
	 * A getter/setter that is used to set modal variant.
	 */
	variant?: "small" | "base" | "large" | "max";
	/**
	 * A getter/setter that is used to get the DOM content of the modal
	 * element and update the content after the modal has been opened.
	 */
	content?: HTMLElement;
	/**
	 * A getter/setter that is used to set modal src.
	 */
	src?: string;
	/**
	 * A getter that is used to get the Window object of the modal iframe
	 * when the modal is used with a `src` attribute. This can only be
	 * accessed when the modal is open, so it is recommended to use `await modal.show()`
	 * before accessing this property.
	 */
	readonly contentWindow?: Window | null;
	/**
	 * Shows the modal element
	 */
	show?(): Promise<void>;
	/**
	 * Hides the modal element
	 */
	hide?(): Promise<void>;
	/**
	 * Toggles the modal element between the showing and hidden states
	 */
	toggle?(): Promise<void>;
	/**
	 * Add 'show' | 'hide' event listeners.
	 * @param type An event name
	 * @param listener A callback triggered when the event name happens
	 */
	addEventListener?(type: "show" | "hide", listener: EventListenerOrEventListenerObject): void;
	/**
	 * Remove 'show' | 'hide' event listeners.
	 * @param type An event name
	 * @param listener A callback to be removed
	 */
	removeEventListener?(type: "show" | "hide", listener: EventListenerOrEventListenerObject): void;
}
interface _UISaveBarAttributes {
	/**
	 * A unique identifier for the save bar
	 */
	id?: string;
	/**
	 * Whether to show a confirmation dialog when the discard button is clicked
	 */
	discardConfirmation?: boolean;
	/**
	 * HTML `<button>` elements to hook into the Save
	 * and Discard buttons of the contextual save bar.
	 *
	 * The button with variant `primary` is the Save button
	 * and the button without a variant is the Discard button.
	 */
	children?: UISaveBarChildren;
}
interface _UISaveBarElement {
	/**
	 * A getter/setter that is used to set discard confirmation.
	 */
	discardConfirmation?: boolean;
	/**
	 * A getter that is used to check if save bar is showing.
	 */
	readonly showing?: boolean;
	/**
	 * Shows the save bar element.
	 */
	show?(): Promise<void>;
	/**
	 * Hides the save bar element.
	 */
	hide?(): Promise<void>;
	/**
	 * Toggles the save bar element between the showing and hidden states.
	 */
	toggle?(): Promise<void>;
	/**
	 * Add 'show' | 'hide' event listeners.
	 * @param type An event name
	 * @param listener A callback triggered when the event name happens
	 */
	addEventListener?(type: "show" | "hide", listener: EventListenerOrEventListenerObject): void;
	/**
	 * Remove 'show' | 'hide' event listeners.
	 * @param type An event name
	 * @param listener A callback to be removed
	 */
	removeEventListener?(type: "show" | "hide", listener: EventListenerOrEventListenerObject): void;
}
interface _UITitleBarAttributes {
	/**
	 * The title of the title bar. Can also be set via <code>document.title</code>.
	 */
	title?: string;
	/**
	 * The children of the title bar.
	 */
	children?: UITitleBarChildren;
}
type ActivationStatus = "active" | "available" | "unavailable";
type AugmentedElement<T extends keyof AugmentedElements> = AugmentedElements[T];
type CartSubscriber = (cart: Cart) => void;
type ClearFunction = () => void;
type DataPoint = string | number | undefined;
type DiscountType = "Percentage" | "FixedAmount";
type ExtensionType = "ui_extension" | "theme_app_extension";
type Finish = (data?: any) => void;
type IdTokenApi = () => Promise<string>;
type IntentAction = "create" | "edit" | "pick";
type IntentResponse = ClosedIntentResponse | SuccessIntentResponse | ErrorIntentResponse;
type IntentType = "settings/LocationDefault" | "settings/OrderIDFormat" | "settings/OrderProcessing" | "settings/StoreDefaults" | "settings/StoreDetails" | "shopify/Article" | "shopify/Catalog" | "shopify/Collection" | "shopify/Customer" | "shopify/Discount" | "shopify/File" | "shopify/Location" | "shopify/Market" | "shopify/Menu" | "shopify/MetafieldDefinition" | "shopify/Metaobject" | "shopify/MetaobjectDefinition" | "shopify/Page" | "shopify/Product" | "shopify/ProductVariant";
type LoadingApi = (isLoading?: boolean) => void;
type Money = string;
type PickerApi = (options: PickerOptions) => Promise<{
	selected: Promise<string[] | undefined>;
}>;
type PosCart = Required<_PosCart>;
type PosClose = () => Promise<void>;
type PosDevice = () => Promise<Device>;
type PosLocation = () => Promise<Location$1>;
type Progress = "incomplete" | "partiallyComplete" | "complete";
type RegisterFunction = (name: string, handler: ToolHandler) => () => void;
type ResourcePickerApi = <ResourceType extends keyof ResourceTypes = keyof ResourceTypes>(options: ResourcePickerOptions<ResourceType>) => Promise<SelectPayload<ResourceType> | undefined>;
type ResourceSelection<Type extends keyof ResourceTypes> = ResourceTypes[Type];
type ResourceTypes = {
	product: Product;
	variant: ProductVariant;
	collection: Collection;
};
type ReviewRequestDeclinedCode = "mobile-app" | "already-reviewed" | "annual-limit-reached" | "cooldown-period" | "merchant-ineligible" | "recently-installed" | "already-open" | "open-in-progress" | "cancelled";
type ReviewRequestResponse = ReviewRequestSuccessResponse | ReviewRequestDeclinedResponse;
type Scope = string;
type SelectPayload<Type extends keyof ResourceTypes> = WithSelection<ResourceSelection<Type>[]>;
type SupportCallback = () => void | Promise<void>;
type ThemeAppBlockTarget = "section";
type ThemeAppEmbedTarget = "head" | "body" | "compliance_head";
type ToastHide = (id: string) => void;
type ToastShow = (message: string, opts?: ToastOptions) => string;
type Tone = "info" | "success" | "warning" | "critical";
type ToolHandler = (input: Record<string, any>) => Record<string, any> | Promise<Record<string, any>>;
type UnregisterFunction = (name: string) => void;
type Unsubscribe = () => void;
type UserApi = () => Promise<User>;
type UserResult = "granted-all" | "declined-all";
type WebVitalsCallback = (payload: WebVitalsReport) => void | Promise<void>;
type WithSelection<T> = T & {
	/**
	 * @private
	 * @deprecated
	 */
	selection: T;
};

export {};
